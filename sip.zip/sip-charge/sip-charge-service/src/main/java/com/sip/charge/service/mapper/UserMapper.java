package com.sip.charge.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sip.charge.model.UserModel;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMapper extends BaseMapper<UserModel> {
}
