package com.sip.charge.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sip.charge.model.UserModel;
import com.sip.common.service.IBaseService;

public interface IUserService extends IBaseService<UserModel> {
}
