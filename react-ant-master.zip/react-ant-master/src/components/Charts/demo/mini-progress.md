---
order: 3
title: 迷你进度条
---

````jsx
import { MiniProgress } from 'ant-design-pro/lib/Charts';

ReactDOM.render(
  <MiniProgress percent={78} strokeWidth={8} target={80} />
, mountNode);
````
